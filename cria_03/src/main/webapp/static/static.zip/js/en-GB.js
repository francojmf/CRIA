/** Translations - save UTF8 NO BOM **/
var fr_screenreader='Screen Reader';
var fr_screenreader_title='Enable screen reader to listen textual contents on page'; 
var fr_notext='Select some text please.'; 
var fr_paused='Paused. Click again to resume.';
var fr_increase='Increase';
var fr_decrease='Decrease';
var fr_reset='Reset';
var fr_highcontrast='Toggle high contrast';
var fr_dyslexic_title='Dyslexic font';