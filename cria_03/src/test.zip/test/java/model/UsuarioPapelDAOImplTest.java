/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.SQLException;
import java.util.List;
import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;

/**
 *
 * @author francojmf
 */

public class UsuarioPapelDAOImplTest {
    @Test
    public void testFindByUsuario(){
        Usuario u;
		try {
			u = new Usuario();
	        u.setId(1L);
	        UsuarioPapelDAO updao = new UsuarioPapelDAOMariaDB10();
	        List<Long> ids = updao.findByNomeUsuario(u);
	        assertEquals(new Long(1L) , ids.get(0));

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

    }
}
