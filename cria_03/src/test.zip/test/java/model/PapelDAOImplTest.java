/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;

/**
 *
 * @author francojmf
 */
public class PapelDAOImplTest {
    
    @Test
    public void testFindById(){
        PapelDAO pdao = new PapelDAOMariaDB10();
        Papel p = pdao.findById(1L);
        Papel p2 = pdao.findById(2L);
        Papel p3 = pdao.findById(3L);
        assertEquals(new Long(1), p.getId());
        assertEquals(new Long(2), p2.getId());
        assertEquals(new Long(3), p3.getId());
    }
}
