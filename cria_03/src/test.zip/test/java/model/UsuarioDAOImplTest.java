/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;

/**
 *
 * @author francojmf
 */
public class UsuarioDAOImplTest {
    @Test
    public void testFindById(){
        UsuarioDAO udao = new UsuarioDAOMariaDB10();
        Usuario u = udao.findById(1L);
        assertEquals("francojmf@hotmail.com", u.getNomeUsuario());
    }
}
